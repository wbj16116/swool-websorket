<?php
$server = new swoole_websocket_server("0.0.0.0", 4888);

$server->on('open', function ($server, $request) {
   // echo '新用户加入';
    $GLOBALS['fd'][$request->fd]=$request->fd;

    echo 'id='.$request->fd;
     $server->push($request->fd,$request->fd);   //每次连接返回给用户新的id
    //echo "server: handshake success with fd{$request->fd}\n";
});

$server->on('message', function ($server, $request) {
//$request->fd   //谁发来的
//$request->data   //发来的内容
    $resut = json_decode($request->data);
    $f_d = $resut[1];
    $t_d = $resut[3];
         $server->push($t_d,$f_d.'对你说：'.$resut[2]);  //主动发送给$t_d
});

$server->on('close', function ($server, $fd) {
    echo "client {$fd} closed\n";
    unset($GLOBALS['fd'][$fd]);
});

$server->start();
